/*********************************************************************
*
* ANSI C Example program:
*    ConnectTwoChannels.c
*
* Example Category:
*    Switch
*
* Description:
*    This example demonstrates how to connect and disconnect two
*    channels on a switch module.
*
* Instructions for Running:
*    1. Change Switch Device and Topology Name as necessary.
*    2. Change Switch Channel 1 and Switch Channel 2 to valid channel
*       names for your switch module.

*
*    The Switch Channels I/O Name control lists the valid channels
*    for the topology in which the switch module was last set. To
*    list channels for another topology, reset the switch module to
*    the new topology.
*
*    Refer to the NI Switches Help for the valid channel names for
*    your switch module.
*
* Steps:
*    1. Set topology.
*    2. Connect specified channels.
*    3. Wait for relay(s) to activate and debounce.
*    4. Disconnect specified channels.
*    5. Wait for relay(s) to activate and debounce.
*    6. Display an error if any.
*
* I/O Connections Overview:
*    Refer to the NI Switches Getting Started Guide and NI Switches
*    Help for information about connecting signals to your switch
*    module.
*
*********************************************************************/

#include <stdio.h>
#include <NIDAQmx.h>

#define DAQmxErrChk(functionCall) if( DAQmxFailed(error=(functionCall)) ) goto Error; else

int main(void)
{
	int32   error=0;
	char    errBuff[2048]={'\0'};

	/*********************************************/
	// DAQmx Connect Code
	/*********************************************/
	DAQmxErrChk (DAQmxSwitchSetTopologyAndReset("SC1Mod4","1127/2-Wire 32x1 Mux"));
	DAQmxErrChk (DAQmxSwitchConnect("/SC1Mod4/ch0","/SC1Mod4/com0",TRUE));
	DAQmxErrChk (DAQmxSwitchDisconnect("/SC1Mod4/ch0","/SC1Mod4/com0",TRUE));

Error:
	if( DAQmxFailed(error) ) {
		DAQmxGetExtendedErrorInfo(errBuff,2048);
		printf("DAQmx Error: %s\n",errBuff);
	}
	printf("End of program, press Enter key to quit\n");
	getchar();
	return 0;
}
