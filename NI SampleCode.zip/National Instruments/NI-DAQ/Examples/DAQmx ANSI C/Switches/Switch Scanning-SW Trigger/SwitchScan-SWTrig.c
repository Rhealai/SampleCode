/*********************************************************************
*
* ANSI C Example program:
*    SwitchScan-SWTrig.c
*
* Example Category:
*    Switch
*
* Description:
*    This example demonstrates how to scan a series of channels on a
*    switch using software scanning.
*
* Instructions for Running:
*    1. Change Switch Device and Topology Name as necessary.
*    2. Change Scan List as necessary.
*    3. Press the Next button to advance to the next entry in the
*       scan list.
*
*    Refer to the NI Switches Help to determine if your switch
*    supports scanning, the scan list syntax, and the valid channel
*    names for your switch module.
*
* Steps:
*    1. Set topology.
*    2. Specify scan list (creates switch scan list task) .
*    3. Select software trigger.
*    4. Start scanning.
*    5. Send software trigger to switch module when Next button
*       pressed.
*    6. Stop scanning.
*    7. Clear switch scan list task.
*    8. Display an error if any.
*
* I/O Connections Overview:
*    Refer to the NI Switches Getting Started Guide and NI Switches
*    Help for information about connecting signals to your switch
*    module.
*
*********************************************************************/

#include <stdio.h>
#include <NIDAQmx.h>
#if defined(WIN32) || defined(_WIN32)
#include <windows.h>
#elif defined(__APPLE__) || defined(__linux__)
#include <time.h>
#endif

#define DAQmxErrChk(functionCall) if( DAQmxFailed(error=(functionCall)) ) goto Error; else

int main(void)
{
	int32       error=0;
	TaskHandle  taskHandle=0;
	char        errBuff[2048]={'\0'};

	/*********************************************/
	// DAQmx Configure Code
	/*********************************************/
	DAQmxErrChk (DAQmxSwitchSetTopologyAndReset("SC1Mod3","1127/2-Wire 32x1 Mux"));
	DAQmxErrChk (DAQmxSwitchCreateScanList("/SC1Mod3/ch0:15->com0;",&taskHandle));
	DAQmxErrChk (DAQmxSetAdvTrigType(taskHandle, DAQmx_Val_Software));
	DAQmxErrChk (DAQmxSetSwitchScanRepeatMode(taskHandle, DAQmx_Val_Cont));

	/*********************************************/
	// DAQmx Start Code
	/*********************************************/
	DAQmxErrChk (DAQmxStartTask(taskHandle));

	printf("Scanning continuously. Press Ctrl+C to interrupt\n");
	while( 1 ) {
		/*********************************************/
		// DAQmx Advance Code
		/*********************************************/
		DAQmxErrChk (DAQmxSendSoftwareTrigger(taskHandle,DAQmx_Val_AdvanceTrigger));

		#if defined(WIN32) || defined(_WIN32)
			Sleep(50);
		#elif defined(__APPLE__) || defined(__linux__)
			struct timespec ts = {0, 50000000};
			nanosleep(&ts, 0);
		#else
			#error - This example requires a platform specific sleep call.
		#endif
	}

Error:
	if( DAQmxFailed(error) )
		DAQmxGetExtendedErrorInfo(errBuff,2048);
	if( taskHandle!=0 ) {
		/*********************************************/
		// DAQmx Stop Code
		/*********************************************/
		DAQmxStopTask(taskHandle);
		DAQmxClearTask(taskHandle);
	}
	if( DAQmxFailed(error) )
		printf("DAQmx Error: %s\n",errBuff);
	printf("End of program, press Enter key to quit\n");
	getchar();
	return 0;
}
