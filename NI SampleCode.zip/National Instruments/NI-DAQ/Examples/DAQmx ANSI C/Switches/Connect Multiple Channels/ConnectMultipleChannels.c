/*********************************************************************
*
* ANSI C Example program:
*    ConnectMultipleChannels.c
*
* Example Category:
*    Switch
*
* Description:
*    This example demonstrates how to connect and disconnect multiple
*    channels on a switch module.
*
* Instructions for Running:
*    1. Change Switch Device and Topology Name as necessary.
*    2. Change Connection List to valid channel names for your switch
*       module.

*
*    Refer to the NI Switches Help for the valid channel names for
*    your switch module.
*
* Steps:
*    1. Set topology.
*    2. Make connections specified by Connection List.
*    3. Wait for relay(s) to activate and debounce.
*    4. Disconnect previous connections.
*    5. Wait for relay(s) to activate and debounce.
*    6. Display an error if any.
*
* I/O Connections Overview:
*    Refer to the NI Switches Getting Started Guide and NI Switches
*    Help for information about connecting signals to your switch
*    module.
*
*********************************************************************/

#include <stdio.h>
#include <NIDAQmx.h>

#define DAQmxErrChk(functionCall) if( DAQmxFailed(error=(functionCall)) ) goto Error; else

int main(void)
{
	int32   error=0;
	char    errBuff[2048]={'\0'};

	/*********************************************/
	// DAQmx Connect Code
	/*********************************************/
	DAQmxErrChk (DAQmxSwitchSetTopologyAndReset("SC1Mod1","1129/2-Wire 4x64 Matrix"));
	DAQmxErrChk (DAQmxSwitchConnectMulti("/SC1Mod1/r0->c0,/SC1Mod1/r1->c1,/SC1Mod1/r2->c2",FALSE));
	DAQmxErrChk (DAQmxSwitchWaitForSettling("SC1Mod1"));
	DAQmxErrChk (DAQmxSwitchDisconnectMulti("/SC1Mod1/r0->c0,/SC1Mod1/r1->c1,/SC1Mod1/r2->c2",FALSE));
	DAQmxErrChk (DAQmxSwitchWaitForSettling("SC1Mod1"));

Error:
	if( DAQmxFailed(error) ) {
		DAQmxGetExtendedErrorInfo(errBuff,2048);
		printf("DAQmx Error: %s\n",errBuff);
	}
	printf("End of program, press Enter key to quit\n");
	getchar();
	return 0;
}
