/*********************************************************************
*
* ANSI C Example program:
*    SequenceConnectionsOnSwitch.c
*
* Example Category:
*    Switch
*
* Description:
*    This example demonstrates how to scan a series of channels on a
*    switch using software scanning.
*
* Instructions for Running:
*    1. Change Switch Device and Topology Name as necessary.
*    2. Change each set of elements in Switch Channel 1 List and
*       Switch Channel 2 List to the names of the channels on your
*       switch module.
*
* Steps:
*    1. Set topology.
*    2. Disconnect previous connection and wait for relay(s) to
*       activate (except when no previous connection exists).
*    3. Connect channel in specified element of Switch Channel 1 List
*       to channel in corresponding element of Switch Channel 2 List.
*    4. Wait for relay(s) to activate.
*    5. Display errors if any.
*
* I/O Connections Overview:
*    Refer to the NI Switches Getting Started Guide and NI Switches
*    Help for information about connecting signals to your switch
*    module.
*
*********************************************************************/

#include <stdio.h>
#include <NIDAQmx.h>

#define DAQmxErrChk(functionCall) if( DAQmxFailed (error=(functionCall)) ) goto Error; else

#define SWITCH_DEVICE "SC1Mod1"
#define SWITCH_TOPOLOGY "1127/2-Wire 32x1 Mux"
#define NUM_CONNECT 4

static const char *channel1[NUM_CONNECT] = { "/SC1Mod1/ch0", "/SC1Mod1/ch1", "/SC1Mod1/ch2", "/SC1Mod1/ch3" };
static const char *channel2[NUM_CONNECT] = { "/SC1Mod1/com0", "/SC1Mod1/com0", "/SC1Mod1/com0", "/SC1Mod1/com0" };

int main (void)
{
	int32	error = 0;
	char	errBuff[2048] =	"";
	int		i;
	
	/* Reset the switch device */
	DAQmxErrChk (DAQmxSwitchSetTopologyAndReset (SWITCH_DEVICE, SWITCH_TOPOLOGY));
			
	for (i = 0; i < NUM_CONNECT; ++i) {
		if (i) {
			/* Disconnect previously connected channels and allow settling */
			DAQmxErrChk (DAQmxSwitchDisconnect (channel1[i-1], channel2[i-1], 1));
		}
		/* Connect specified channels and allow settling */
		DAQmxErrChk (DAQmxSwitchConnect (channel1[i], channel2[i], 1));
	}

Error:
	if (DAQmxFailed (error)) {
		DAQmxGetExtendedErrorInfo (errBuff, 2048);
		printf ("DAQmx Error: %s\n", errBuff);
	}	
	printf("End of program, press Enter key to quit\n");
	getchar();
	return 0;
} 