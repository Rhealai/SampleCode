/*********************************************************************
*
* ANSI C Example program:
*    ControlIndividualRelay.c
*
* Example Category:
*    Switch
*
* Description:
*    This example demonstrates how to control an individual relay on
*    a switch module.
*
* Instructions for Running:
*    1. Select a Switch Device and Topology Name.
*    2. Select a Relay Name for a valid relay on the switch module.
*    3. Select a relay action (open or close).
*
*    The Switch Relay I/O Name control lists the valid relays for the
*    topology in which the switch module was last set. To list relays
*    for another topology, reset the switch module to the new
*    topology.
*
*    Refer to the Switches Help for the valid relay names and valid
*    device names for your switch module.
*
* Steps:
*    1. Reset the switch and set the topology.
*    2. Open or close the relay.
*    3. Wait for the relay to activate and debounce.
*    4. Display an error if any.
*
* I/O Connections Overview:
*    Refer to the NI Switches Getting Started Guide and NI Switches
*    Help for information about connecting signals to your switch
*    module.
*
*********************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <NIDAQmx.h>

#define DAQmxErrChk(functionCall) if( DAQmxFailed(error=(functionCall)) ) goto Error; else

int main(void)
{
	int32   error=0;
	char    errBuff[2048]={'\0'};
	char	*device = "SC1Mod3";
	char	*relayName = "/SC1Mod3/ch0";
	int     relayAction=0;  // 0 = open; 1 = close

	DAQmxErrChk (DAQmxSwitchSetTopologyAndReset(device,DAQmx_Val_Switch_Topology_1127_2_Wire_32x1_Mux));

	if( relayAction ) {
		printf("Closing relay %s\n",relayName);
		DAQmxErrChk (DAQmxSwitchCloseRelays(relayName,1));
	} else {
		printf("Opening relay %s\n",relayName);
		DAQmxErrChk (DAQmxSwitchOpenRelays(relayName,1));
	}

	DAQmxErrChk (DAQmxSwitchWaitForSettling(device));

Error:
	if( DAQmxFailed(error) ) {
		DAQmxGetExtendedErrorInfo(errBuff,2048);
		printf("DAQmx Error: %s\n",errBuff);
	}
	printf("End of program, press Enter key to quit\n");
	getchar();
	return 0;
}
