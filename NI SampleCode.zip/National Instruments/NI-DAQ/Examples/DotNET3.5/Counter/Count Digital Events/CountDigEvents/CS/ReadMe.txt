Example Title:           CountDigEvents

Example Filename:        CountDigEvents.sln

Category:                CI

Description:             This example demonstrates how to count digital events on
                         a Counter Input Channel. The Initial Count, Count
                         Direction, and Edge are all configurable.This example
                         shows how to count edges on the counter's default source
                         pin, but could easily be expanded to count edges on any
                         PFI, RTSI, or internal signal. Non-buffered event
                         counting can also use a digital pause trigger which
                         could be added to this example by configuring the
                         Trigger object for the Task.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
