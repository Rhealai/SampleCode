Example Title:           MeasureGpsTimestamp

Example Filename:        MeasureGpsTimestamp.sln

Category:                CI

Description:             This example demonstrates how to use a GPS counter to
                         update the current time.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
