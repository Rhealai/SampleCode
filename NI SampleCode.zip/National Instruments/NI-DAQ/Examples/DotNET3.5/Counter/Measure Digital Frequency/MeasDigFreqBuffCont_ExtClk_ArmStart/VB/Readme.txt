Example Title:           MeasDigFreqBuffCont_ExtClk_ArmStart

Example Filename:        MeasDigFreqBuffCont_ExtClk_ArmStart.sln

Category:                CI

Description:             This example demonstrates how to continually measure the
                         frequency on a Counter Input Channel 
                         with a sample clock and arm start trigger. This example
                         shows how to measure frequency with a counter on any
                         PFI, RTSI, or internal signal.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
