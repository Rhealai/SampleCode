Example Title:           PWMCounterOutput

Example Filename:        PWMCounterOutput.sln

Category:                Control

Description:             This example demonstrates how to do Pulse Width
                         Modulation using Analog Input and Counter Output.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
