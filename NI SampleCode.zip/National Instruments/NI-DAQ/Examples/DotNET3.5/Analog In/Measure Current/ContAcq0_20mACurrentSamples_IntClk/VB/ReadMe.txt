Example Title:           ContAcq0_20mACurrentSamples_IntClk

Example Filename:        ContAcq0_20mACurrentSamples_IntClk.sln

Category:                AI

Description:             This example demonstrates how to continuously measure
                         current using an internal hardware clock for timing.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
