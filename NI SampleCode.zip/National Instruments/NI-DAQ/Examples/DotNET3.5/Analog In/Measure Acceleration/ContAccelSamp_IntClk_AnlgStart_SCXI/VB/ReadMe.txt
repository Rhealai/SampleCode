Example Title:           ContAccelSamp_IntClk_AnlgStart_SCXI

Example Filename:        ContAcqAccelSamp_SCXI.sln

Category:                AI

Description:             This example demonstrates how to make continuous,
                         hardware-timed acceleration measurements using an
                         SCXI-153x module.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
