Example Title:           ContAcqRTDSamples_IntClk

Example Filename:        ContAcqRTDSamples_IntClk.sln

Category:                AI

Description:             This example demonstrates how to acquire temperature
                         from an RTD using the internal clock of the DAQ device.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
