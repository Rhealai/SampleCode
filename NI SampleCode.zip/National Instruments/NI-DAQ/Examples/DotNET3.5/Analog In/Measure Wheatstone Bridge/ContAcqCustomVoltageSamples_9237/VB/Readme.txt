Example Title:           ContAcqCustomVoltageSamples_9237

Example Filename:        ContAcqCustomVoltageSamples_9237.sln

Category:                AI

Description:             This example performs Wheatstone Bridge measurements
                         with offset nulling if desired.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
