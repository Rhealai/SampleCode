Example Title:           AcqStrainSamples

Example Filename:        AcqStrainSamples.sln

Category:                AI

Description:             This example demonstrates how to perform a strain
                         measurement.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
