Example Title:           AcqOneVoltageSample

Example Filename:        AcqOneVoltageSample.sln

Category:                AI

Description:             This example demonstrates how to acquire a single
                         reading from a constant or slowly varying signal.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
