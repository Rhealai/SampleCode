Example Title:           ConAcqVoltSmpls_ConfigFilter_SCXI114x

Example Filename:        ConAcqVoltSmpls_ConfigFilter_SCXI114x.sln

Category:                AI

Description:             This example demonstrates how to acquire and filter an
                         analog signal using the SCXI-114x.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
