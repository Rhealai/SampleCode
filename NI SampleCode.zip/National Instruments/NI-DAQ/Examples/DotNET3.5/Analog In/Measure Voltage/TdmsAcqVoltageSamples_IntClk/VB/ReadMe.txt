Example Title:           TdmsAcqVoltageSamples_IntClk

Example Filename:        TdmsAcqVoltageSamples_IntClk.sln

Category:                AI

Description:             This example demonstrates how to acquire a finite amount
                         while simultaneously streaming that data to a binary
                         file.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
