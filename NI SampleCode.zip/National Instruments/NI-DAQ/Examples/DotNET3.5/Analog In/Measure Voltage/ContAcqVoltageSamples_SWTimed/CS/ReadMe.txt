Example Title:           ContAcqVoltageSamples_SWTimed

Example Filename:        ContAcqVoltageSamples_SWTimed.sln

Category:                AI

Description:             This example demonstrates how to acquire a continuous
                         amount of data using a software timer.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
