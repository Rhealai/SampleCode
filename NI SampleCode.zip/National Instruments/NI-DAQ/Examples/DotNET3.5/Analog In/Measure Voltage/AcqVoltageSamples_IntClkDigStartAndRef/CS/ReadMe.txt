Example Title:           AcqVoltageSamples_IntClkDigStartAndRef

Example Filename:        AcqVoltageSamples_IntClkDigStartAndRef.sln

Category:                AI

Description:             This example demonstrates how to acquire a finite amount
                         of data using an internal clock and a digital start and
                         reference trigger.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
