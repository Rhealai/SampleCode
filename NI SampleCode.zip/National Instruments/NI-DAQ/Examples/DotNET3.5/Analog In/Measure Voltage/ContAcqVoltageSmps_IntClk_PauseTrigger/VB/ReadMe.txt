Example Title:           ContAcqVoltageSmps_IntClk_PauseTrigger

Example Filename:        ContAcqVoltageSmps_IntClk_PauseTrigger.sln

Category:                AI

Description:             This example demonstrates how to continuously acquire
                         data using DAQ device's internal clock and a digital
                         pause trigger.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
