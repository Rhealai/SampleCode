Example Title:           ContAcqVoltageSmpls_IntClkAnalogStart

Example Filename:        ContAcqVoltageSmpls_IntClkAnalogStart.sln

Category:                AI

Description:             This example demonstrates how to continuously acquire
                         data using the DAQ device's internal clock and an analog
                         slope start trigger.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
