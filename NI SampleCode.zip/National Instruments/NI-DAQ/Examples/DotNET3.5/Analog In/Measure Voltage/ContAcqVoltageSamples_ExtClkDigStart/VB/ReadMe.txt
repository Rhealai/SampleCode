Example Title:           ContAcqVoltageSamples_ExtClkDigStart

Example Filename:        ContAcqVoltageSamples_ExtClkDigStart.sln

Category:                AI

Description:             This example demonstrates how to continuously acquire
                         analog voltage data using an external clock, started by
                         a digital trigger.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
