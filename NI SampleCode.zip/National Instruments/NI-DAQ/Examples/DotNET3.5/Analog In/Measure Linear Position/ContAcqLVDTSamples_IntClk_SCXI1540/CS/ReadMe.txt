Example Title:           ContAcqLVDTSamples_IntClk_SCXI1540

Example Filename:        ContAcqLVDTSamples_IntClk_SCXI1540.sln

Category:                AI

Description:             This example demonstrates how to make a continuous,
                         hardware-timed acceleration measurement using an
                         SCXI-1540 module.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
