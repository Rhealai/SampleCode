Example Title:           ContAcqFreq_IntClk_SCXI1126

Example Filename:        ContAcqFreq_IntClk_SCXI1126.sln

Category:                AI

Description:             This example demonstrates how to acquire frequency data
                         from an SCXI-1126 using the DAQ device's internal clock.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
