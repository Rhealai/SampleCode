Example Title:           ContGenVoltageWfm_ExtClk

Example Filename:        ContGenVoltageWfm_ExtClk.sln

Category:                AO

Description:             This example demonstrates how to continuously output a
                         periodic waveform using an external clock.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
