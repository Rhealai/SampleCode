Example Title:           GenMultVoltUpdatesIntClk_DigStart

Example Filename:        GenMultVoltUpdatesIntClk_DigStart.sln

Category:                AO

Description:             This example demonstrates how to output multiple voltage
                         updates (samples) to an analog output channel.  The
                         generation starts when a digital trigger is received.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
