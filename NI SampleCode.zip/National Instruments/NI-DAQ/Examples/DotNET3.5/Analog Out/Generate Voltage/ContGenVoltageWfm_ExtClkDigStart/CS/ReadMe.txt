Example Title:           ContGenVoltageWfm_ExtClkDigStart

Example Filename:        ContGenVoltageWfm_ExtClkDigStart.sln

Category:                AO

Description:             This example demonstrates how to continuously output a
                         waveform using an external sample clock and a digital
                         start trigger.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
