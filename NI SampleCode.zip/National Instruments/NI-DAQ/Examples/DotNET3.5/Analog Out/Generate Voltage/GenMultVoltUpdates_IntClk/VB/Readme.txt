Example Title:           GenMultVoltUpdates_IntClk

Example Filename:        GenMultVoltUpdates_IntClk.sln

Category:                AO

Description:             This example demonstrates how to output multiple voltage
                         updates (samples) to an analog output channel.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual Basic .NET

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
