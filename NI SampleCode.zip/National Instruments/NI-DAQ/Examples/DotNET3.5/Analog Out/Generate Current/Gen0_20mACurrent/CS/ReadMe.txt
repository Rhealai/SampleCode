Example Title:           Gen0_20mACurrent

Example Filename:        Gen0_20mACurrent.sln

Category:                AO

Description:             This example demonstrates how to generate a single
                         current value on a single current output channel of a
                         SCXI-1124 module and NI-6238/6239 M-Series devices.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
