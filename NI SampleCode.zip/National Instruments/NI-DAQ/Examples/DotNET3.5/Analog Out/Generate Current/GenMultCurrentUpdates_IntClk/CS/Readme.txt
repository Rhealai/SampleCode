Example Title:           GenMultCurrentUpdates_IntClk

Example Filename:        GenMultCurrentUpdates_IntClk.sln

Category:                AO

Description:             This example demonstrates how to output a finite number
                         of current samples to an Analog Output Channel using an
                         internal sample clock.

Software Group:          Measurement Studio

Required Software:       Visual Studio .NET

Language:                Visual C#

Language Version:        8.0

Driver Name:             DAQmx

Driver Version:          14.1
